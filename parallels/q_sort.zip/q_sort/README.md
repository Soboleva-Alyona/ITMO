
### Результаты 5 запусков на случайных массивах (в файле [Main.kt](src/main/kotlin/Main.kt)):
Run number 1 for array of size=10000000

Sequential time: 3222 ms

Parallel time: 1553 ms

---------------------------------------
Run number 2 for array of size=10000000

Sequential time: 2998 ms

Parallel time: 1517 ms

---------------------------------------
Run number 3 for array of size=10000000

Sequential time: 3236 ms

Parallel time: 1118 ms

---------------------------------------
Run number 4 for array of size=10000000

Sequential time: 3074 ms

Parallel time: 1135 ms

---------------------------------------
Run number 5 for array of size=10000000

Sequential time: 3418 ms

Parallel time: 1167 ms

---------------------------------------
### Average sequential time: 3189 ms VS Average parallel time: 1298 ms
Parallel is 2.457319 faster then sequential