interface QuickSort {
    fun sort(array: ArrayList<Int>): ArrayList<Int>
}